#!/usr/bin/env python
# encoding: utf-8

# VARS: app_name
readme_md_string = """
{{app_name}}
=====
"""
